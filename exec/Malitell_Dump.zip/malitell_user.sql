-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i10c208.p.ssafy.io    Database: malitell
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_seq` int NOT NULL AUTO_INCREMENT,
  `alram_message` varchar(255) DEFAULT NULL,
  `birth` varchar(255) NOT NULL,
  `career_period` int NOT NULL,
  `certificate_field` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `education_field` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `grade` double NOT NULL,
  `name` varchar(255) NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) NOT NULL,
  `professional_field` varchar(255) DEFAULT NULL,
  `profile_img` text,
  `read_check` int NOT NULL,
  `refresh_token` varchar(255) DEFAULT NULL,
  `role` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) NOT NULL,
  PRIMARY KEY (`user_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,NULL,'19980228',0,NULL,NULL,NULL,'hjaehyeon98@gmail.com','M',0,'한재현','짱재현','$2a$10$kX4FE7pFQzlpn4Skks6Da.cZZ/6xOjgES25Tdn9GUDT4HTXWD2BUW','010-5705-6540',NULL,NULL,1,'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJoYW5qYWVoeWVvbiIsInJvbGUiOiJST0xFX0NMSUVOVCIsImlhdCI6MTcwODA1MTY2MCwiZXhwIjoxNzA5MjYxMjYwfQ.v02TXStMtoLZpMHb-ljkKNgbJq7RT43M_T4LjfFLM1o','ROLE_CLIENT',NULL,'hanjaehyeon'),(2,NULL,'19810212',17,'임상심리전문가 정신보건 임상심리사 1급 중독심리전문가','치료 과정은 여행입니다. 상담 치료의 여행 가이드는 상담치료사 입니다.','전남대학교 임상심리 전공 박사 수료','test@naver.com','M',0,'임남열','임남열','$2a$10$ta8gPYdlAqVdm0ki4Fe.IOyHykcoHaAyP0sY7EMiaYD.I63xMfE4S','010-8211-0108','임상 심리\n도박 중독 심리\n가정 폭력\n양성 평등\n유가족 상담','https://file.notion.so/f/f/22f7e1c7-e82c-4b17-897e-938b069965ee/25217589-1e0e-4df2-9da1-c43eaeeb5f93/Untitled.png?id=68007ec4-f95f-481d-bf52-60a2e58364f3&table=block&spaceId=22f7e1c7-e82c-4b17-897e-938b069965ee&expirationTimestamp=1708135200000&signature=JA_Sk57pjZwkdoNgp4du-pycg28uTKjm-8M_WZnRyfI&downloadName=Untitled.png',1,'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJuYW15b3VsbGltIiwicm9sZSI6IlJPTEVfQ09VTlNFTE9SIiwiaWF0IjoxNzA4MDUwNTM3LCJleHAiOjE3MDkyNjAxMzd9.EiMugoneoXmSpB5I0nQovouqgf3UGj68PtZMOSSOLzE','ROLE_COUNSELOR',NULL,'namyoullim'),(3,NULL,'19800315',15,'정신분석 전문가','당신의 마음을 함께 읽어나가는 여정에 동행하겠습니다.','서울대학교 심리학 박사 전공 수료','test@naver.com','W',0,'이화진','이화진','$2a$10$mtXoF0FUUPc/ACP/zc.YgOnt.o5yRVwhUcQk5Q.UwlXUEWj9UzB72','01072626304','정신분석학','https://file.notion.so/f/f/22f7e1c7-e82c-4b17-897e-938b069965ee/0b5269a9-22f2-4a4a-9909-9cc1b6635c87/image_(3).png?id=15855ed0-3584-4a59-a105-4ee4272d9db8&table=block&spaceId=22f7e1c7-e82c-4b17-897e-938b069965ee&expirationTimestamp=1708135200000&signature=t2Jg3QBaKbgN2sELWKqZuRop2HYcPztC9s2uFK7mCeE&downloadName=image+%283%29.png',1,NULL,'ROLE_COUNSELOR',NULL,'hwajinlee'),(4,NULL,'19920909',10,'스트레스 분석 전문가','직장 생활에서의 스트레스, 함께 나누고 해결해봅시다.','서강대학교 심리학 석사 전공 수료','test@naver.com','M',0,'장민석','장민석','$2a$10$NU2T.hzZu7.cIEH4BuSI/uXe7zbCdd.D5hg9m3N5m9mRzzehPzhbW','01056789012','직장인의 스트레스 관리','https://file.notion.so/f/f/22f7e1c7-e82c-4b17-897e-938b069965ee/12651ef3-81d4-498d-b08d-9b7078bdc150/image_(2).png?id=a2c4c291-7fa0-4fec-90a8-f1971ebc4482&table=block&spaceId=22f7e1c7-e82c-4b17-897e-938b069965ee&expirationTimestamp=1708135200000&signature=z6a2PkfC_H-56fpQ9zwuZLAaI8my_1wOHh53Nq8uhLs&downloadName=image+%282%29.png',1,NULL,'ROLE_COUNSELOR',NULL,'minseokjang'),(5,NULL,'19881010',9,'무의식 분석 전문가','무의식의 세계를 함께 탐색하며, 꿈을 통해 자아를 이해해봅시다.','한국외국어대학교 심리학 전공','test@naver.com','M',0,'이승민','이승민','$2a$10$hCZHrj8vfywSerDLD9VZyO5C/sDxG08FDO2TDs8CL3fy16J6OSwX6','01056789012','무의식과 꿈 해석','https://file.notion.so/f/f/22f7e1c7-e82c-4b17-897e-938b069965ee/cb6b7baa-9829-4fd1-85b4-d4a19f678762/image_(1).png?id=bb82dea3-fc36-41c3-b224-1749e867238c&table=block&spaceId=22f7e1c7-e82c-4b17-897e-938b069965ee&expirationTimestamp=1708135200000&signature=e7A6LFnc4mvhDPBS4wTT5vAz7n5RTG--OfRKVeHCh_s&downloadName=image+%281%29.png',1,NULL,'ROLE_COUNSELOR',NULL,'seongminlee'),(6,NULL,'19920909',7,'청소년상담 전문가','소년기, 그 어려움을 함께 나누고 이해하는 공간을 제공하겠습니다.','한양대학교 심리학 석사 전공','test@naver.com','W',0,'윤지아','윤지아','$2a$10$HBOLaKpmO1kbw7mmb43tUOOIUC1hDlZhP31HTiNYxubb0Drtz2rnO','01056789012','청소년 상담','https://file.notion.so/f/f/22f7e1c7-e82c-4b17-897e-938b069965ee/6857f37a-38ce-4b36-9db3-cade188daaf1/Untitled.png?id=ce505265-3e97-467d-802f-d31ea0dc791b&table=block&spaceId=22f7e1c7-e82c-4b17-897e-938b069965ee&expirationTimestamp=1708135200000&signature=BFOTSXp-Nu3wF15MlTufwt8pRilhN-0kvV78n90O52s&downloadName=Untitled.png',1,'eyJhbGciOiJIUzI1NiJ9.eyJ1c2VySWQiOiJqaWF5b29uIiwicm9sZSI6IlJPTEVfQ09VTlNFTE9SIiwiaWF0IjoxNzA4MDI3ODE0LCJleHAiOjE3MDkyMzc0MTR9.Ngdw6L7LetvZhomi4EEOOht2WJTLny58N0iYHw49Mxs','ROLE_COUNSELOR',NULL,'jiayoon'),(7,NULL,'19990604',10,NULL,NULL,NULL,'wncks2546@naver.com','M',0,'윤주찬','짱주찬','$2a$10$qX0UbZOHpUU4h.d.E/4zNO/1./9CRQVOd0.x7QbcHNnujKzMW5K.C','010-5566-7679',NULL,NULL,1,NULL,'ROLE_COUNSELOR',NULL,'wncks123'),(8,NULL,'19980210',0,NULL,NULL,NULL,'tpwls101@naver.com','F',0,'유세진','짱세진','$2a$10$5fMFS25xDB1e5DyxS7vituWt.jxUQJV4HwL/8znve4XswiWKRD7tS','010-6604-1442',NULL,NULL,1,NULL,'ROLE_CLIENT',NULL,'tpwls101');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 12:00:31
