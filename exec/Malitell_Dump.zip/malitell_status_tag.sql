-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i10c208.p.ssafy.io    Database: malitell
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `status_tag`
--

DROP TABLE IF EXISTS `status_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `status_tag` (
  `status_tag_seq` int NOT NULL AUTO_INCREMENT,
  `tag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`status_tag_seq`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status_tag`
--

LOCK TABLES `status_tag` WRITE;
/*!40000 ALTER TABLE `status_tag` DISABLE KEYS */;
INSERT INTO `status_tag` VALUES (1,'우울'),(2,'불안'),(3,'공황'),(4,'자존감'),(5,'다정한'),(6,'진실성 있는'),(7,'경청하는'),(8,'적극적인 코칭'),(9,'우울'),(10,'불안'),(11,'공황'),(12,'자존감'),(13,'다정한'),(14,'진실성 있는'),(15,'경청하는'),(16,'적극적인 코칭'),(17,'우울'),(18,'불안'),(19,'공황'),(20,'자존감'),(21,'다정한'),(22,'진실성 있는'),(23,'경청하는'),(24,'적극적인 코칭'),(25,'우울'),(26,'불안'),(27,'공황'),(28,'자존감'),(29,'다정한'),(30,'진실성 있는'),(31,'경청하는'),(32,'적극적인 코칭'),(33,'우울'),(34,'불안'),(35,'공황'),(36,'자존감'),(37,'다정한'),(38,'진실성 있는'),(39,'경청하는'),(40,'적극적인 코칭'),(41,'우울'),(42,'불안'),(43,'공황'),(44,'자존감'),(45,'다정한'),(46,'진실성 있는'),(47,'경청하는'),(48,'적극적인 코칭'),(49,'우울'),(50,'불안'),(51,'공황'),(52,'자존감'),(53,'다정한'),(54,'진실성 있는'),(55,'경청하는'),(56,'적극적인 코칭');
/*!40000 ALTER TABLE `status_tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 12:00:27
