-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: i10c208.p.ssafy.io    Database: malitell
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `self_help_group`
--

DROP TABLE IF EXISTS `self_help_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `self_help_group` (
  `self_help_group_seq` int NOT NULL AUTO_INCREMENT,
  `content` text,
  `self_help_type` tinyint DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`self_help_group_seq`),
  CONSTRAINT `self_help_group_chk_1` CHECK ((`self_help_type` between 0 and 4))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `self_help_group`
--

LOCK TABLES `self_help_group` WRITE;
/*!40000 ALTER TABLE `self_help_group` DISABLE KEYS */;
INSERT INTO `self_help_group` VALUES (1,'성실하게 참여하실 분들 모집하고 있습니다!',4,'알콜 중독 자조모임 참가자 모집합니다.'),(2,'안녕하세요. 마리텔의 임남열 상담사입니다.\n저와 상담을 나눈 내담자들과 자조모임을 통해 마음의 응어리들을 해소하고 싶은 사람들을 모집합니다.\n2월 19일 월요일 저녁 7시에 첫 모임을 진행하려고 합니다.\n참가 인원은 6명으로 제한을 하고 내담자들의 참여를 더욱 이끌어내기 위해 메타버스를 통한 자조모임으로 진행하려고 합니다.\n\n회차는 총 3회차로 첫회차에는 서로에 대한 소개와 어떤 아픔을 겪고 있는지 나누는 시간을 갖고 서로를 알게 되는 시간을 가집니다.\n2회차에는 그림치료를 통한 자신의 숨은 내면을 파악하는 시간을 가질 것입니다.\n3회차에는 서로를 위로하고 마음을 해소하는 활동을 통해 마음의 응어리를 덜어낼 수 있는 프로그램을 진행할 예정입니다.\n관심이 있는 내담자분들은 적극적으로 신청해주시기 바랍니다.\n',1,'우울할 땐 우울면');
/*!40000 ALTER TABLE `self_help_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-16 12:00:28
